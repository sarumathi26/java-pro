﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmployeeDetails
{
    class PrintDetails
    {
        public float TotalSalary;
        public int BasicPay;
        public int Allowance;
        public int NetSalary;
    }

}
