﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmployeeDetails
{
    class EmployeeDetails
    {
        private string ename;
        public void AddEmployee(string name)
        {
            ename = name;
            names.Add(name);          
            Console.WriteLine("\n" + names.Count + ".Employee " + name + " added successfully in database");
            
        }
   
        public PrintDetails Totalcount(int salary)
        {
            PrintDetails prd = new PrintDetails();
            prd.BasicPay = salary + 500;
            prd.Allowance = prd.BasicPay / 2;
            prd.NetSalary = prd.BasicPay + prd.Allowance;
            prd.TotalSalary = prd.NetSalary - 1000;
            Console.WriteLine("\n  Salary for " + ename + " :  " + prd.TotalSalary +"\n" );
            return new PrintDetails();
        }

        List<string> names = new List<string>();
       
    }
}
