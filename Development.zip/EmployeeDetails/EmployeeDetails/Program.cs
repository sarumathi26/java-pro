﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Speech.Synthesis;

namespace EmployeeDetails
{
    class Program
    {
        static void Main(string[] args)
        {
            SpeechSynthesizer spe = new SpeechSynthesizer();
            spe.Speak("THE NEWS");

            EmployeeDetails emd = new EmployeeDetails();
            emd.AddEmployee("Ramya");
      
            PrintDetails pde = emd.Totalcount(5000);
           
        }
    }
}
