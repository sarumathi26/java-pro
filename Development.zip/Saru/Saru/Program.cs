﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Saru
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Type the time: ");
            int time1 = int.Parse(Console.ReadLine());

            if (time1 < 8)
            {
                Console.WriteLine("Correct time " + time1);
            }
            else
            {
                Console.WriteLine("Wrong Time");
            }

        }
    }
}