﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DemoClass
{
    class DemoClass
    {
        List<int> num = new List<int>();
        int j = 0,i = 0;

        public void Demo(int a)
        {
            Console.WriteLine("THe incremented number is " + a);
            num.Add(a);
            

                while( j <= 1)
                {
                    j++;
                    Console.WriteLine(j);
                    demo();
                    
                }
                if (1 < 3)
                {
                    Console.WriteLine("Hello");
                   
                }

         }
        public void demo()
        {
            Demo(5);
        }

        public DemoClass(int a)
        {
                Console.WriteLine("THe Program is execute:" + a);
               
        }
    
    }
}