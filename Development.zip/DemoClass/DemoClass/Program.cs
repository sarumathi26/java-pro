﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DemoClass
{
    class Program
    {
        static void Main(string[] args)
       {
            DemoClass demo = new DemoClass(6);
            demo.Demo(5);
            Console.WriteLine(demo.ToString());
        }
    }
}